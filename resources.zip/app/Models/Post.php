<?php



namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'title',      // Pastikan ini termasuk
        'content',
        'image',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function likes()
    {
        return $this->belongsToMany(User::class, 'likes');
    }

    public function followers()
    {
        return $this->belongsToMany(User::class, 'post_following', 'post_id', 'follower_id');
   }

   public function hiddenByUsers()
{
    return $this->belongsToMany(User::class, 'hidden_posts', 'post_id', 'user_id');
}
}

