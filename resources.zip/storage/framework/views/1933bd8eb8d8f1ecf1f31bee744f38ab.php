<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mb-3">

        <!-- Menampilkan foto profil dan nama pengguna dari user yang membuat post -->
        <div class="d-flex align-items-center mb-3">
            <img src="<?php echo e($post->user->biodata && $post->user->biodata->photo ? asset('storage/' . $post->user->biodata->photo) : 'https://via.placeholder.com/50'); ?>" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;" alt="Foto Pengguna">
            <div class="ml-3">
                <h5 class="mb-0"><?php echo e($post->user->name); ?></h5>
                <small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small>
            </div>
        </div>

        <?php if($post->image): ?>
            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top" alt="Gambar Post">
        <?php endif; ?>
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <!-- Tombol Like/Unlike dan Komentar -->
                <div>
                    <form action="<?php echo e(route('post.like', $post->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 text-dark">
                            <i class="fas fa-heart <?php echo e($post->likes->contains(Auth::id()) ? 'text-danger' : 'text-muted'); ?>"></i>
                        </button>
                    </form>
                    <span><?php echo e($post->likes->count()); ?> Suka</span> <!-- Menampilkan jumlah like -->
                </div>
                <div>
                    <span><?php echo e($post->comments->count()); ?> Komentar</span> <!-- Menampilkan jumlah komentar -->
                </div>
            </div>

            <h5 class="card-title"><?php echo e($post->title); ?></h5>
            <p class="card-text"><?php echo e($post->content); ?></p>

            <h6 class="mt-3">Komentar:</h6>
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="comment mb-4">
                    <div class="d-flex align-items-start">
                        <img src="<?php echo e($comment->user->biodata && $comment->user->biodata->photo ? asset('storage/' . $comment->user->biodata->photo) : 'https://via.placeholder.com/50'); ?>" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;" alt="Foto Pengguna">
                        <div class="ml-3">
                            <h6 class="font-weight-bold mb-1"><?php echo e($comment->user->name); ?></h6>
                            <p class="mb-1"><?php echo e($comment->content); ?></p>
                            <small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>

                            <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="reply mt-3">
                                    <div class="d-flex align-items-start">
                                        <img src="<?php echo e($reply->user->biodata && $reply->user->biodata->photo ? asset('storage/' . $reply->user->biodata->photo) : 'https://via.placeholder.com/50'); ?>" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;" alt="Foto Pengguna">
                                        <div class="ml-2">
                                            <strong class="d-block mb-1"><?php echo e($reply->user->name); ?></strong>
                                            <p class="mb-1"><?php echo e($reply->content); ?></p>
                                            <small class="text-muted"><?php echo e($reply->created_at->diffForHumans()); ?></small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <button class="btn btn-link mt-3 toggle-reply-form" data-comment-id="<?php echo e($comment->id); ?>">Balas</button>
                            <form action="<?php echo e(route('post.reply', ['post_id' => $post->id, 'comment_id' => $comment->id])); ?>" method="POST" class="reply-form mt-2" id="reply-form-<?php echo e($comment->id); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="text" name="reply_text" placeholder="Balas komentar ini..." class="form-control" required>
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">Balas</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<!-- Bottom Navigation Bar -->
<div class="bottom-nav">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
        <i class="fas fa-user"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .card {
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .card-img-top {
        max-width: 100%;
        height: auto;
        object-fit: cover;
    }
    .card-body {
        padding: 16px;
    }
    .comment {
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
    }
    .reply {
        border-bottom: 1px solid #f1f1f1;
        padding-bottom: 5px;
    }
    .input-group {
        margin-top: 10px;
    }
    .bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #fff;
        border-top: 1px solid #ddd;
        display: flex;
        justify-content: space-around;
        padding: 10px 0;
    }
    .bottom-nav a {
        color: #333;
        font-size: 20px;
    }
    .bottom-nav a.active {
        color: #007bff;
    }
    .reply-form {
        display: none;
    }
    .reply-form.active {
        display: block;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.toggle-reply-form').forEach(button => {
            button.addEventListener('click', function () {
                const commentId = this.getAttribute('data-comment-id');
                const replyForm = document.getElementById(`reply-form-${commentId}`);
                replyForm.classList.toggle('active');
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/posts/show.blade.php ENDPATH**/ ?>