<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Pengikut <?php echo e($user->name); ?></h1>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-sm-6 col-md-4 mb-4">
                <div class="card">
                    <div class="card-body text-center">
                        <?php if($follower->biodata && $follower->biodata->photo): ?>
                            <img src="<?php echo e(asset('storage/' . $follower->biodata->photo)); ?>" alt="Foto Pengikut" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/100" alt="Foto Default" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                        <?php endif; ?>
                        <h5 class="card-title mt-2"><?php echo e($follower->name); ?></h5>
                        <p class="card-text"><strong>Email:</strong> <?php echo e($follower->email); ?></p>

                        <?php if(Auth::user()->isFollowing($follower->id)): ?>
                            <!-- Button for unfollowing the user -->
                            <form action="<?php echo e(route('user.unfollow', $follower->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-user-minus"></i> Unfollow</button>
                            </form>
                        <?php else: ?>
                            <!-- Button for following the user -->
                            <form action="<?php echo e(route('user.follow', $follower->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> Follow</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center">Tidak ada pengikut ditemukan.</p>
        <?php endif; ?>
    </div>
</div>

 <!-- Bottom Navigation Bar -->
 <div class="bottom-nav">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
        <i class="fas fa-user"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/user/followers.blade.php ENDPATH**/ ?>