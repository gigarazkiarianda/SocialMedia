<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Tampilkan pesan selamat datang -->
    <div class="row align-items-center mb-4">
        <div class="col-md-4 d-flex justify-content-center">
            <?php if(Auth::user()->biodata && Auth::user()->biodata->photo): ?>
                <img src="<?php echo e(asset('storage/' . Auth::user()->biodata->photo)); ?>" alt="Foto Profil" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
            <?php else: ?>
                <img src="https://via.placeholder.com/150" alt="Foto Default" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <h1>Selamat datang, <?php echo e(Auth::user()->name); ?>!</h1>
            <p><strong>Email:</strong> <?php echo e(Auth::user()->email); ?></p>
        </div>
    </div>

    <?php if($posts->count()): ?>
        <h2 class="mb-4">Postingan dari Pengguna yang Anda Ikuti</h2>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-4 position-relative">
                        <div class="card-header d-flex align-items-center">
                            <div class="d-flex align-items-center flex-grow-1">
                                <?php if($post->user->biodata && $post->user->biodata->photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $post->user->biodata->photo)); ?>" alt="Foto Pengguna" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                <?php else: ?>
                                    <img src="https://via.placeholder.com/40" alt="Foto Default" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                <?php endif; ?>
                                <div class="ml-2">
                                    <h6 class="m-0"><?php echo e($post->user->name); ?></h6>
                                    <small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small>
                                </div>
                            </div>
                            <!-- Tombol tiga titik -->
                            <div class="ml-auto">
                                <button class="btn btn-link text-dark" type="button" data-toggle="modal" data-target="#postActionsModal<?php echo e($post->id); ?>">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <!-- Modal untuk tindakan postingan -->
                                <div class="modal fade" id="postActionsModal<?php echo e($post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="postActionsModalLabel<?php echo e($post->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="postActionsModalLabel<?php echo e($post->id); ?>">Tindakan Postingan</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?php if($post->user_id == Auth::id()): ?>
                                                    <a href="<?php echo e(route('post.edit', $post->id)); ?>" class="btn btn-primary btn-block">Edit Post</a>
                                                    <form action="<?php echo e(route('post.destroy', $post->id)); ?>" method="POST" class="d-inline-block w-100">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-block">Hapus Post</button>
                                                    </form>
                                                <?php else: ?>
                                                    <!-- Tombol untuk sembunyikan post -->
                                                    <?php
                                                        $isHidden = \App\Models\HiddenPost::where('user_id', Auth::id())->where('post_id', $post->id)->exists();
                                                    ?>

                                                    <?php if($isHidden): ?>
                                                        <form action="<?php echo e(route('post.unhide', $post->id)); ?>" method="POST" class="d-inline-block w-100">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-secondary btn-block">Tampilkan Post</button>
                                                        </form>
                                                    <?php else: ?>
                                                        <form action="<?php echo e(route('post.hide', $post->id)); ?>" method="POST" class="d-inline-block w-100">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-secondary btn-block">Sembunyikan Post</button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <!-- Tombol Share -->
                                                <a href="#" class="btn btn-info btn-block">Bagikan Post</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($post->image): ?>
                            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top" alt="Gambar Postingan">
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <!-- Tombol Like/Unlike dan Komentar -->
                                <div>
                                    <form action="<?php echo e(route('post.like', $post->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-link p-0 text-dark">
                                            <i class="fas fa-heart <?php echo e($post->likes->contains(Auth::id()) ? 'text-danger' : 'text-muted'); ?>"></i>
                                        </button>
                                    </form>
                                    <span><?php echo e($post->likes->count()); ?> Suka</span> <!-- Menampilkan jumlah like -->
                                </div>
                                <div>
                                    <span><?php echo e($post->comments->count()); ?> Komentar</span> <!-- Menampilkan jumlah komentar -->
                                </div>
                            </div>
                            <h5 class="card-title"><?php echo e($post->title); ?></h5>
                            <p class="card-text"><?php echo e($post->content); ?></p>

                            <!-- Form Input Komentar -->
                            <form action="<?php echo e(route('post.comment', $post->id)); ?>" method="POST" class="w-100 mb-3">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="comment" placeholder="Tambahkan komentar" required>
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-paper-plane"></i> Kirim
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <!-- Daftar Komentar dan Balasan -->
                            <div class="mt-3">
                                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media mb-3">
                                        <?php if($comment->user->biodata && $comment->user->biodata->photo): ?>
                                            <img src="<?php echo e(asset('storage/' . $comment->user->biodata->photo)); ?>" alt="Foto Pengguna" class="mr-3 rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                        <?php else: ?>
                                            <img src="https://via.placeholder.com/40" alt="Foto Default" class="mr-3 rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                        <?php endif; ?>
                                        <div class="media-body">
                                            <h6 class="mt-0"><?php echo e($comment->user->name); ?></h6>
                                            <p><?php echo e($comment->content); ?></p>
                                            <!-- Form Input Balasan -->
                                            <form action="<?php echo e(route('post.reply', ['post_id' => $post->id, 'comment_id' => $comment->id])); ?>" method="POST" class="d-inline-block">
                                                <?php echo csrf_field(); ?>
                                                <input type="text" name="reply" class="form-control mb-2" placeholder="Balas komentar" required>
                                                <button type="submit" class="btn btn-link p-0">
                                                    <i class="fas fa-reply"></i> Balas
                                                </button>
                                            </form>
                                            <!-- Daftar Balasan Komentar -->
                                            <div class="mt-2">
                                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="media mb-2">
                                                        <?php if($reply->user->biodata && $reply->user->biodata->photo): ?>
                                                            <img src="<?php echo e(asset('storage/' . $reply->user->biodata->photo)); ?>" alt="Foto Pengguna" class="mr-3 rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                                        <?php else: ?>
                                                            <img src="https://via.placeholder.com/40" alt="Foto Default" class="mr-3 rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                                        <?php endif; ?>
                                                        <div class="media-body">
                                                            <h6 class="mt-0"><?php echo e($reply->user->name); ?></h6>
                                                            <p><?php echo e($reply->content); ?></p>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center">
            <p>Tidak ada postingan dari pengguna yang Anda ikuti.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/dashboard.blade.php ENDPATH**/ ?>