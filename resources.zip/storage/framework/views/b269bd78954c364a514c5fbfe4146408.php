<?php $__env->startSection('content'); ?>
<div class="container">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>

        <!-- Tambahkan tombol Register di bawah tombol Login -->
        <div class="mt-3">
            <a href="<?php echo e(route('register')); ?>" class="btn btn-secondary">Register</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/auth/login.blade.php ENDPATH**/ ?>