<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Notifikasi</h1>

        <?php if($notifications->isEmpty()): ?>
            <div class="alert alert-info">
                Tidak ada notifikasi baru.
            </div>
        <?php else: ?>
            <div class="list-group">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Memastikan bahwa data adalah string sebelum decode
                        $data = is_string($notification->data) ? json_decode($notification->data, true) : $notification->data;
                    ?>

                    <div class="list-group-item d-flex justify-content-between align-items-center <?php echo e($notification->read ? 'list-group-item-light' : 'list-group-item-primary'); ?>">
                        <div>
                            <?php switch($notification->type):
                                case ('follow'): ?>
                                    <strong><?php echo e($data['user_name'] ?? 'User'); ?></strong> mulai mengikuti Anda.
                                    <?php break; ?>
                                <?php case ('like'): ?>
                                    <strong><?php echo e($data['user_name'] ?? 'User'); ?></strong> menyukai foto Anda.
                                    <?php break; ?>
                                <?php case ('comment'): ?>
                                    <strong><?php echo e($data['user_name'] ?? 'User'); ?></strong> mengomentari foto Anda: "<?php echo e($data['comment_content'] ?? 'Komentar'); ?>"
                                    <?php break; ?>
                                <?php default: ?>
                                    Notifikasi baru
                            <?php endswitch; ?>
                        </div>

                        <small class="text-muted">
                            <?php echo e($notification->created_at->diffForHumans()); ?>

                        </small>

                        <form action="<?php echo e(route('notifications.markAsRead', $notification->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary btn-sm <?php echo e($notification->read ? 'disabled' : ''); ?>">
                                Tandai sebagai dibaca
                            </button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bottom Navigation Bar -->
    <div class="bottom-nav">
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
            <i class="fas fa-home"></i>
        </a>
        <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
            <i class="fas fa-comments"></i>
        </a>
        <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
            <i class="fas fa-plus"></i>
        </a>
        <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
            <i class="fas fa-user"></i>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/notifications/index.blade.php ENDPATH**/ ?>