<?php $__env->startSection('content'); ?>
<style>
    .status-indicator {
        position: absolute;
        bottom: 0;
        right: 0;
        width: 15px;
        height: 15px;
        border-radius: 50%;
        border: 2px solid #fff;
        background-color: #ccc; /* Warna default offline */
    }

    .status-indicator.online {
        background-color: #28a745; /* Warna online */
    }

    .status-indicator.offline {
        background-color: #dc3545; /* Warna offline */
    }
</style>

<div class="container">
    <div class="row mb-4">
        <!-- Foto Profil -->
        <div class="col-md-3 d-flex justify-content-center position-relative">
            <?php if($user->biodata && $user->biodata->photo): ?>
                <img src="<?php echo e(asset('storage/' . $user->biodata->photo)); ?>" alt="Foto Profil" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
            <?php else: ?>
                <img src="https://via.placeholder.com/150" alt="Foto Default" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
            <?php endif; ?>

            <!-- Indikator Status -->
            <div class="status-indicator <?php echo e($user->is_online ? 'online' : 'offline'); ?>"></div>
        </div>

        <!-- Informasi Pengguna dan Statistik -->
        <div class="col-md-9 d-flex flex-column justify-content-center">
            <!-- Nama Pengguna dengan Status -->
            <div class="d-flex align-items-center mb-3">
                <h2 class="text-center mb-0"><?php echo e($user->biodata ? $user->biodata->full_name : 'Pengguna'); ?></h2>
            </div>

            <!-- Statistik Followers, Following, dan Posts -->
            <div class="row mt-4">
                <div class="col-4 text-center">
                    <a href="<?php echo e(route('user.followers', $user->id)); ?>" class="d-block">
                        <strong style="font-size: 1.25rem;">Pengikut:</strong> <?php echo e($user->followers->count()); ?>

                    </a>
                </div>
                <div class="col-4 text-center">
                    <a href="<?php echo e(route('user.following', $user->id)); ?>" class="d-block">
                        <strong style="font-size: 1.25rem;">Mengikuti:</strong> <?php echo e($user->following->count()); ?>

                    </a>
                </div>
                <div class="col-4 text-center">
                    <strong style="font-size: 1.25rem;">Postingan:</strong> <?php echo e($user->posts->count()); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- Biodata -->
    <?php if($user->biodata): ?>
        <div class="card mb-3">
            <div class="card-body">
                <h4 class="card-title"><?php echo e($user->biodata->full_name); ?></h4>
                <p class="card-text"><strong>Tanggal Lahir:</strong> <?php echo e($user->biodata->birth_date); ?></p>
                <p class="card-text"><strong>Tempat Lahir:</strong> <?php echo e($user->biodata->birth_place); ?></p>
            </div>
        </div>
    <?php else: ?>
        <p>Tidak ada biodata tersedia.</p>
    <?php endif; ?>

    <!-- Follow/Unfollow dan Tombol Pesan -->
    <?php if(auth()->guard()->check()): ?>
        <div class="text-center mb-4">
            <div class="d-flex justify-content-center">
                <?php if(Auth::user()->isFollowing($user->id)): ?>
                    <form action="<?php echo e(route('user.unfollow', $user->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-user-minus"></i> Unfollow</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('user.follow', $user->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> Follow</button>
                    </form>
                <?php endif; ?>

                <!-- Tombol Pesan -->
                <?php
                    $chatRoom = \App\Models\ChatRoom::where(function ($query) use ($user) {
                        $query->where('user1_id', Auth::id())
                              ->where('user2_id', $user->id);
                    })->orWhere(function ($query) use ($user) {
                        $query->where('user1_id', $user->id)
                              ->where('user2_id', Auth::id());
                    })->first();
                ?>

                <?php if($chatRoom): ?>
                    <a href="<?php echo e(route('chat.show', ['id' => $chatRoom->id])); ?>" class="btn btn-success btn-sm ml-2"><i class="fas fa-envelope"></i> Pesan</a>
                <?php else: ?>
                    <a href="<?php echo e(route('chat.create', ['user_id' => $user->id])); ?>" class="btn btn-success btn-sm ml-2"><i class="fas fa-envelope"></i> Pesan</a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Postingan dari Pengguna -->
    <div class="row mt-4">
        <?php if($user->posts->count()): ?>
            <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="d-block">
                        <div class="card" style="cursor: pointer;">
                            <?php if($post->image): ?>
                                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top" alt="<?php echo e($post->caption); ?>">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/500" class="card-img-top" alt="Gambar Postingan">
                            <?php endif; ?>
                            <div class="card-body">
                                <p class="card-text"><?php echo e($post->caption); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>Belum ada postingan.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/user/profile.blade.php ENDPATH**/ ?>