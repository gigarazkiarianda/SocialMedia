<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Chat Rooms</h1>

    <!-- Add Chat Room Form -->
    <form action="<?php echo e(route('chat.store')); ?>" method="POST" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="user">Select User to Chat With</label>
            <select id="user" name="user_id" class="form-control" required>
                <option value="" disabled selected>Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Start Chat</button>
    </form>

    <!-- Chat Rooms List -->
    <ul class="list-group">
        <?php $__currentLoopData = $chatRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex align-items-center">
                <?php
                    $otherUser = $chatRoom->user1->id === Auth::id() ? $chatRoom->user2 : $chatRoom->user1;
                ?>

                <!-- User Name and Recent Message -->
                <div class="d-flex align-items-center mr-3">
                    <?php if($otherUser->biodata && $otherUser->biodata->photo): ?>
                        <img src="<?php echo e(asset('storage/' . $otherUser->biodata->photo)); ?>" alt="Profile Photo" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/100" alt="Default Photo" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                    <?php endif; ?>

                    <div class="ml-3">
                        <strong><?php echo e($otherUser->name); ?></strong><br>
                        <?php
                            $latestMessage = $chatRoom->messages->last();
                        ?>
                        <?php if($latestMessage): ?>
                            <span><?php echo e($latestMessage->message); ?></span>
                            <span class="message-status">
                                <?php if($latestMessage->seen === 0): ?>
                                    <i class="fas fa-check-circle text-muted"></i> <!-- Pending -->
                                <?php elseif($latestMessage->seen === 1): ?>
                                    <i class="fas fa-check-circle text-primary"></i> <!-- Sent -->
                                <?php elseif($latestMessage->seen === 2): ?>
                                    <i class="fas fa-check-double text-success"></i> <!-- Read -->
                                <?php endif; ?>
                            </span>
                        <?php else: ?>
                            <span>No messages yet.</span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- View Chat Button -->
                <a href="<?php echo e(route('chat.show', $chatRoom->id)); ?>" class="btn btn-info btn-sm ml-auto">View Chat</a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<!-- Bottom Navigation Bar -->
<div class="bottom-nav">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
        <i class="fas fa-user"></i>
    </a>
</div>

<?php $__env->startSection('styles'); ?>
<style>
    .message-status {
        display: inline-block;
        margin-left: 10px;
    }
    .message-status .fa-check-circle {
        font-size: 1.2em;
    }
    .message-status .fa-check-double {
        font-size: 1.2em;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/chat/index.blade.php ENDPATH**/ ?>