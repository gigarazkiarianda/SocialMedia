<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Bagian Profil -->
    <div class="row align-items-center mb-4">
        <div class="col-12 col-md-4 d-flex justify-content-center mb-3 mb-md-0">
            <?php if(Auth::user()->biodata && Auth::user()->biodata->photo): ?>
                <img src="<?php echo e(asset('storage/' . Auth::user()->biodata->photo)); ?>" alt="Foto Profil" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
            <?php else: ?>
                <img src="https://via.placeholder.com/150" alt="Foto Default" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
            <?php endif; ?>
        </div>

        <div class="col-12 col-md-8">
            <h1><?php echo e(Auth::user()->name); ?></h1>
        </div>
    </div>

     <!-- Pengikut, Mengikuti, dan Postingan -->
     <div class="row text-center mb-4">
        <div class="col-4">
            <h4 class="text-dark">Postingan</h4>
            <p class="text-dark"><?php echo e($posts->count()); ?></p>
        </div>
        <div class="col-4">
            <h4><a href="<?php echo e(route('user.followers', Auth::user()->id)); ?>" class="text-dark">Pengikut</a></h4>
            <p class="text-dark"><?php echo e(Auth::user()->followers->count()); ?></p>
        </div>
        <div class="col-4">
            <h4><a href="<?php echo e(route('user.following', Auth::user()->id)); ?>" class="text-dark">Mengikuti</a></h4>
            <p class="text-dark"><?php echo e(Auth::user()->following->count()); ?></p>
        </div>
    </div>

    <!-- Bagian Biodata -->
    <?php if($biodata): ?>
        <div class="card mb-3">
            <div class="card-body">
                <h4 class="card-title"><?php echo e($biodata->full_name); ?></h4>
                <p class="card-text"><strong>Tanggal Lahir:</strong> <?php echo e($biodata->birth_date); ?></p>
                <p class="card-text"><strong>Tempat Lahir:</strong> <?php echo e($biodata->birth_place); ?></p>
                <a href="<?php echo e(route('biodata.edit', $biodata->id)); ?>" class="btn btn-primary">Edit Biodata</a>
            </div>
        </div>
    <?php else: ?>
        <p>Tidak ada biodata. <a href="<?php echo e(route('biodata.create')); ?>">Buat sekarang</a>.</p>
    <?php endif; ?>

    <!-- Bagian Grid Postingan -->
    <h2 class="mt-4 mb-3">Postingan Anda</h2>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-sm-6 col-md-4 mb-4">
                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="card-link">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="card-img-top" alt="Gambar Postingan">
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center">Anda belum memiliki postingan.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Bottom Navigation Bar -->
<div class="bottom-nav">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
        <i class="fas fa-user"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .card-img-top {
        width: 100%;
        height: auto;
        object-fit: cover;
        aspect-ratio: 1/1;
    }
    .bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: #fff;
        border-top: 1px solid #ddd;
        display: flex;
        justify-content: space-around;
        padding: 10px 0;
    }
    .bottom-nav a {
        color: #333;
        font-size: 24px;
    }
    .bottom-nav a.active {
        color: #007bff;
    }
    .card-link {
        text-decoration: none;
        color: inherit;
    }
    .card-link:hover .card {
        border-color: #007bff;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/user/myprofile.blade.php ENDPATH**/ ?>