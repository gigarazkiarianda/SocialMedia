<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Buat Postingan Baru</h2>

    <form action="<?php echo e(route('post.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Judul</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>

        <div class="form-group">
            <label for="content">Konten</label>
            <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
        </div>

        <div class="form-group">
            <label for="image">Gambar</label>
            <input type="file" class="form-control-file" id="image" name="image" accept="image/*" required>
        </div>

        <div class="form-group">
            <img id="image-preview" src="#" alt="Image Preview" style="display: none; max-width: 100%;">
        </div>

        <button type="submit" class="btn btn-primary">Buat Postingan</button>
    </form>
</div>

<!-- Bottom Navigation Bar -->
<div class="bottom-nav">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
        <i class="fas fa-user"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    #image-preview {
        max-height: 400px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('image').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const imagePreview = document.getElementById('image-preview');
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/posts/create.blade.php ENDPATH**/ ?>