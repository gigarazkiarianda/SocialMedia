<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Hasil Pencarian untuk "<?php echo e($query); ?>"</h1>

    <?php if($users->isEmpty()): ?>
        <p>Tidak ada pengguna ditemukan.</p>
    <?php else: ?>
        <ul class="list-group">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <a href="<?php echo e(route('user.profile', $user->id)); ?>"><?php echo e($user->name); ?></a> (<?php echo e($user->email); ?>)
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>

<!-- Bottom Navigation Bar -->
<div class="bottom-nav">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>">
        <i class="fas fa-user"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/user/search.blade.php ENDPATH**/ ?>