<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex align-items-center mb-4">
        <?php
            // Menentukan pengguna lain dalam chat room
            $otherUser = $chatRoom->user1->id === Auth::id() ? $chatRoom->user2 : $chatRoom->user1;

            // Mengambil waktu saat ini
            $currentTime = now();

            // Mengambil waktu terakhir dilihat, jika ada
            $lastSeen = $otherUser->last_seen ? \Carbon\Carbon::parse($otherUser->last_seen) : null;

            // Menghitung selisih waktu dalam menit antara waktu sekarang dengan waktu terakhir dilihat
            $onlineStatus = $lastSeen ? $lastSeen->diffInMinutes($currentTime) : null;
        ?>

        <!-- Tampilkan foto profil atau gambar default -->
        <?php if($otherUser->biodata && $otherUser->biodata->photo): ?>
            <img src="<?php echo e(asset('storage/' . $otherUser->biodata->photo)); ?>" alt="Foto Profil" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
        <?php else: ?>
            <img src="https://via.placeholder.com/150" alt="Foto Default" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
        <?php endif; ?>

        <div class="ml-3">
            <h3><?php echo e($otherUser->name); ?></h3>
            <!-- Tampilkan status online atau last seen -->
            <?php if($lastSeen): ?>
                <?php if($onlineStatus < 1): ?>
                    <p>Status: <span class="text-success">Online</span></p>
                <?php else: ?>
                    <p>Status: <span class="text-muted">Terakhir dilihat <?php echo e($lastSeen->diffForHumans()); ?></span></p>
                <?php endif; ?>
            <?php else: ?>
                <p>Status: <span class="text-muted">Tidak diketahui</span></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Kontainer Chat -->
    <div class="chat-container" style="position: relative; height: calc(100vh - 160px);">
        <!-- Pesan Chat -->
        <div class="chat-messages" style="height: calc(100% - 50px); overflow-y: auto; padding: 10px; border: 1px solid #ddd; border-radius: 5px; background: #f9f9f9; padding-bottom: 60px;">

            <?php
                $lastDisplayedDate = null;
            ?>

            <?php $__currentLoopData = $chatRoom->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $utcDate = $message->created_at->format('Y-m-d');
                    $localDate = \Carbon\Carbon::parse($message->created_at)->setTimezone('Asia/Jakarta')->format('d F Y');
                ?>

                <?php if($lastDisplayedDate !== $localDate): ?>
                    <!-- Tampilkan tanggal sebelumnya jika berbeda dari lastDisplayedDate -->
                    <?php if($lastDisplayedDate !== null): ?>
                        <div class="text-center mb-2" style="margin: 10px 0; font-size: 0.75rem; color: gray;">
                            <h5><?php echo e($lastDisplayedDate); ?></h5>
                        </div>
                    <?php endif; ?>
                    <?php
                        $lastDisplayedDate = $localDate;
                    ?>
                <?php endif; ?>

                <!-- Tampilkan pesan -->
                <div class="message mb-1 d-flex <?php echo e($message->sender->id === Auth::id() ? 'justify-content-end' : 'justify-content-start'); ?>" style="margin-bottom: 5px;">
                    <div class="message-box p-2 rounded <?php echo e($message->sender->id === Auth::id() ? 'bg-success text-white' : 'bg-dark text-white'); ?>" style="max-width: 75%; word-wrap: break-word;">
                        <p class="mb-1"><?php echo e($message->message); ?></p>
                        <div class="text-center" style="font-size: 0.8em; color: white;">
                            <?php echo e(\Carbon\Carbon::parse($message->created_at)->setTimezone('Asia/Jakarta')->format('H:i')); ?>

                            <?php if($message->sender->id === Auth::id()): ?>
                                <small>
                                    <?php if($message->seen_by_recipient): ?>
                                        <!-- Tanda pesan dibaca -->
                                        <i class="fas fa-check-double text-primary" title="Pesan dibaca"></i>
                                    <?php elseif(!$message->seen): ?>
                                        <!-- Tanda pesan terkirim -->
                                        <i class="fas fa-check text-muted" title="Pesan terkirim"></i>
                                    <?php else: ?>
                                        <!-- Tanda pesan terkirim -->
                                        <i class="fas fa-check-double text-muted" title="Pesan terkirim"></i>
                                    <?php endif; ?>
                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Tampilkan tanggal terakhir jika berbeda dari lastDisplayedDate -->
            <?php if($lastDisplayedDate !== null): ?>
                <div class="text-center mb-2" style="margin: 10px 0; font-size: 0.75rem; color: gray;">
                    <h5><?php echo e($lastDisplayedDate); ?></h5>
                </div>
            <?php endif; ?>
        </div>

        <!-- Form Kirim Pesan -->
        <form action="<?php echo e(route('message.store', $chatRoom->id)); ?>" method="POST" class="chat-form" style="position: absolute; bottom: 0; left: 0; right: 0; background: #fff; padding: 10px; border-top: 1px solid #ddd; z-index: 10; display: flex; align-items: center;">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-0 flex-grow-1">
                <textarea id="message" name="message" class="form-control" rows="2" placeholder="Ketik pesan Anda di sini..." required style="resize: none;"></textarea>
            </div>
            <button type="submit" class="btn btn-primary ml-2">Kirim</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function(){
        // Auto scroll ke bawah chat messages
        const chatMessages = $('.chat-messages');
        chatMessages.scrollTop(chatMessages[0].scrollHeight);
    });
</script>

<!-- Navigasi Bawah -->
<div class="bottom-nav" style="position: fixed; bottom: 0; left: 0; right: 0; background: #fff; border-top: 1px solid #ddd; z-index: 100; display: flex; justify-content: space-around; padding: 10px 0;">
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" style="flex: 1; text-align: center;">
        <i class="fas fa-home"></i>
    </a>
    <a href="<?php echo e(route('chat.index')); ?>" class="<?php echo e(request()->routeIs('chat.index') ? 'active' : ''); ?>" style="flex: 1; text-align: center;">
        <i class="fas fa-comments"></i>
    </a>
    <a href="<?php echo e(route('post.create')); ?>" class="<?php echo e(request()->routeIs('post.create') ? 'active' : ''); ?>" style="flex: 1; text-align: center;">
        <i class="fas fa-plus"></i>
    </a>
    <a href="<?php echo e(route('user.myprofile')); ?>" class="<?php echo e(request()->routeIs('user.myprofile') ? 'active' : ''); ?>" style="flex: 1; text-align: center;">
        <i class="fas fa-user"></i>
    </a>
</div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\razki\koding\my project\SocialMedia\resources\views/chat/show.blade.php ENDPATH**/ ?>